﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace BaiTap_CheckBox
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
